package ysoserial;


/**
 * @author mbechler
 *
 */
public interface CustomDeserializer {

    
    Class<?> getCustomDeserializer ();

}
